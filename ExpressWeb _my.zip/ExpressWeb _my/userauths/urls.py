from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
urlpatterns = [
    path('', views.Login, name='Login'),
    path('Registration/', views.Registration, name='Registration'),
    path('Logout/', views.Logout, name='Logout'),
    path('find_user/', views.Find_user, name='find_user'),
    path('CheckOTP/', views.CheckOTP, name='CheckOTP'),
    # path('reset_password/', views.reset_password, name='reset_password'),
    path('UserProfile/', views.UserProfile, name='UserProfile'),

]