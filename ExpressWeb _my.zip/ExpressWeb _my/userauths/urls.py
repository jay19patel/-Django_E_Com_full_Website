from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.urls import path,include
urlpatterns = [
    path('', views.Login, name='Login'),
    path('Registration/', views.Registration, name='Registration'),
    path('Logout/', views.Logout, name='Logout'),
    path('find_user/', views.Find_user, name='find_user'),
    path('CheckOTP/', views.CheckOTP, name='CheckOTP'),
    path('UserProfile/', views.UserProfile, name='UserProfile'),
    path('google_account/', views.google_account, name='google_account'),



]