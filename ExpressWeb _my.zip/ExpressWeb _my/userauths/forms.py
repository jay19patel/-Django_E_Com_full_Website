from typing import Any, Dict
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.forms import ModelForm
from userauths.models import User as Custom_User
from django import forms
class UserRegistration(UserCreationForm):
  class Meta :
    model = Custom_User
    fields = ['username', 'email', 'password1', 'password2','mobile_number','citypin']

  def clean_username(self) -> Dict[str, Any]:
     data = super().clean()
     username = self.data.get('username')
     if len(username)<4 or username in ['$','&','*']:
        raise forms.ValidationError("Try Another longer Username ")
     return data
  
  def clean_mobile_number(self) -> Dict[str, Any]:
     data = super().clean()
     mobile_number = self.data.get('mobile_number')
     if len(mobile_number)<10 :
        raise forms.ValidationError(" Mobile Number Must be 10 Numbers ")
     return data


class UserProfileForm(ModelForm):
    class Meta:
        model = Custom_User
        fields = ['first_name','last_name','username', 'email','mobile_number','citypin']
