from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.forms import ModelForm
from userauths.models import User as Custom_User
class UserRegistration(UserCreationForm):
  class Meta :
    model = Custom_User
    fields = ['username', 'email', 'password1', 'password2','mobile_number','citypin']


class UserProfileForm(ModelForm):
    class Meta:
        model = Custom_User
        fields = ['first_name','last_name','username', 'email','mobile_number','citypin']
