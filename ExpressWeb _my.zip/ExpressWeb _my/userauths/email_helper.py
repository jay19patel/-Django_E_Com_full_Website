from django.core.mail import send_mail
import uuid

from django.conf import settings


def send_forgate_password_mail(email,token):
    token = str(uuid.uuid4())
    subject = "Forgate password link"
    message = f"URL: {token}"
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [email]
    send_mail(subject,message,email_from,recipient_list)