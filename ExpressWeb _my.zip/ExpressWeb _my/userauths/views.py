from django.shortcuts import render,HttpResponse,redirect
from userauths.forms import UserRegistration,UserProfileForm
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from userauths.models import User as Custome_user
import time
import uuid
from .email_helper import send_forgate_password_mail
# Create your views here.

def Login(request):
    # if request.user.is_authenticated:
    #     messages.success(request,"You are alredy Login ")
    #     return redirect ("HomePage")
    
    # if request.method == "POST":
    #     username = request.POST.get('username')
    #     password = request.POST.get('password')
    #     print(username,password)

    #     user = authenticate(username=username, password=password)
    #     if user is not None:
    #         login(request,user)
    #         messages.success(request,"Login Successfull")
    #         return redirect ("HomePage")
    #     else:
    #         messages.error(request,"Not Match ")
    # return render (request,'Auths/Login.html')
    return  redirect("account_login")


def Registration(request):
    # form = UserRegistration()
    # if request.method == "POST":
    #     form = UserRegistration(request.POST)
    #     if form.is_valid():
    #         unewuser = form.save()
    #         messages.success(request," account Create Successfully :>")
    #         return redirect ("Login")
    #     else:
    #         messages.success(request,"Input Is Not valid :< ")
    # context = {'form' : form}
    # return render (request,'Auths/Registration.html',context)
    return  redirect("account_signup")




def Logout(request):
    # logout(request)
    # messages.warning(request,"Logout ")
    
    # return render (request,'Auths/Registration.html')
    return redirect ('account_logout')
    
import jwt 
import datetime
import random
def Find_user(request):
    if request.method=="POST":
        username = request.POST.get("username")
        print("Find USer name :",username)
        user_obj = Custome_user.objects.filter(username=username).first()
        if user_obj :
            user_data = Custome_user.objects.get(username=user_obj.username)
            print("Usser Data",user_data.email)
            otp = random.randint(1111,9999)
            print("OTP:",otp)
            payload = {
                "otp" : str(otp) ,
                'username':username,
                "exp" : datetime.datetime.utcnow() + datetime.timedelta(minutes=1),
                "iat" :  datetime.datetime.utcnow()
            }

            token = jwt.encode(payload,"123321",algorithm = "HS256").decode('utf-8')
            request.session["otp"]= token
            # send_forgate_password_mail(user_data.email,token)
            messages.success(request,"Email Send in ",user_data.email)
            time.sleep(1)
            return redirect("CheckOTP")
        else:
            messages.success(request,"Username Not found !! ")
    return render (request,'Auths/Find_user.html')
    # return HttpResponse("PAGE IS UNDER CUNSTRUCTION ")


def CheckOTP(request):
    if request.method=="POST":
        otp = request.POST.get("otp")
        pass1 = request.POST.get("pass1")
        pass2 = request.POST.get("pass2")

        # 
        myotp = request.session["otp"]
        print("RECIVED TOKEN:",myotp)
        paylod = jwt.decode(myotp,"123321",algorithm = ["HS256"])
        username = paylod['username']

        if otp == paylod['otp']:
            if pass1==pass2:
                u = Custome_user.objects.get(username=username)
                u.set_password(pass1)
                u.save()
            return redirect ("Login")
        else:
            messages.success(request,"OTP Dose Not Match ")
            print("PAssword NOt Match ")
        

    return render (request,'Auths/chnagePass.html')

from core.models import SaveLikes,UserAddress,Product

def UserProfile(request):
    profile = Custome_user.objects.get(email=request.user)
    products = SaveLikes.objects.filter(user=request.user)
    address = UserAddress.objects.filter(user=request.user)
    contex ={'profile':profile,"products":products,'address':address}
    if request.method=="POST":
        r_id = request.POST.get('r_id')
        print(r_id)
        product = Product.objects.get(id=r_id)
        likedata = SaveLikes.objects.filter(user =request.user,product =product)
        likedata.delete()

    return render (request,'Auths/UserProfile.html',contex)



def google_account(request):
    return  redirect("/accounts/login/")