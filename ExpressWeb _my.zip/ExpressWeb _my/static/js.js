

// function AddAddress(){
//  let add = window.prompt("Eneter Adress");
//  let pin = window.prompt("Eneter Pincode ");

//  let url = 'http://127.0.0.1:8000/address_add/'
//  const data = {
//   address: add,
//   pincode :pin
// };


//  fetch(url, {
//   method: 'GET',
//   headers: {
//     'Content-Type': 'application/json'
//   },
//   body: JSON.stringify(data)
// })

// .then(response => {
//   if (response.ok) {
//     console.log('Address added successfully');
//   } else {
//     console.error('Error adding address');
//   }
// })
// .catch(error => {
//   console.error('Error:', error);
// });

// }