from django.db import models
from userauths.models import User


def user_dir_path(instance,file):
    return f"user_/{file}"

class Category(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self) -> str:
        return self.name


class Product(models.Model):
    title = models.CharField(max_length=100)
    price = models.IntegerField()
    discount = models.IntegerField(default=5 ,null=True)
    image = models.ImageField(upload_to=user_dir_path)
    description = models.TextField(max_length=500,null=True)
    category = models.ForeignKey(Category,on_delete=models.CASCADE)
    stock = models.IntegerField(default=10)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('on_the_way', 'On the Way'),
        ('delivered', 'Delivered'),
        ('delivered_confirm', 'Delivered  Confirm'),
    ]


class UserAddress(models.Model):
    user= models.ForeignKey(User,on_delete=models.CASCADE)
    address = models.TextField(max_length=200)
    pincode = models.CharField(max_length=10)

    def __str__(self) -> str:
        return self.pincode
    

class CartItem(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,on_delete=models.CASCADE,related_name='user_cart_item')
    qnty = models.PositiveIntegerField(default=1)
    status = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f"{self.product.title}{self.user.username}"
    
    def total_price(product):        
        total = [i.product.price*i.qnty for i in product]
        return sum(total)

PAYMENT_METHOD = [
        ('cash', 'Cash'),
        ('paytm', 'PayTM'),
        ('pending', 'Pending'),
    ]

class Cart(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    order_id = models.CharField(max_length=50)
    product= models.ManyToManyField(CartItem)
    total_price = models.IntegerField(default=99)
    date = models.DateTimeField(auto_now_add=True)
    product_status = models.CharField(choices=STATUS_CHOICES,default="pending",max_length=20)
    status = models.BooleanField(default=False)
    address = models.ForeignKey(UserAddress,null=True,blank=True,on_delete=models.CASCADE,related_name="user_address")
    payment = models.CharField(choices=PAYMENT_METHOD,default="pending",max_length=20)

    
    def __str__(self) -> str:
        data = [ i.product.title for i in self.product.all()]
        return str(data)
    def count_item(self):
        data = [ i.product.title for i in self.product.all()]
        return len(data)
    
class SaveLikes(models.Model):
    user= models.ForeignKey(User,on_delete=models.CASCADE)
    product= models.ForeignKey(Product,on_delete=models.CASCADE)
    likes = models.IntegerField(default=0)

    def __str__(self) -> str:
        data = f"{self.product}_like_{self.likes}"
        return data