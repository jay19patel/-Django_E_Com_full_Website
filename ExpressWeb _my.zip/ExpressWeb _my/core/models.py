from django.db import models
from userauths.models import User


def user_dir_path(instance,file):
    return f"user_{instance.user.id}/{file}"

class Category(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self) -> str:
        return self.name


class Product(models.Model):
    title = models.CharField(max_length=100)
    user =models.ForeignKey(User ,on_delete=models.CASCADE)
    price = models.IntegerField()
    discount = models.IntegerField(default=5 ,null=True)
    image = models.ImageField(upload_to=user_dir_path)
    description = models.TextField(max_length=500,null=True)
    category = models.ForeignKey(Category,on_delete=models.CASCADE)
    sale = models.BooleanField(default=False)
    stock = models.IntegerField(default=10)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


STATUS_CHOICES = [
        ('no_buy', 'No Buy'),
        ('pending', 'Pending'),
        ('on_the_way', 'On the Way'),
        ('delivered', 'Delivered'),
        ('delivered_confirm', 'Delivered  Confirm'),
    ]

class UserOder(models.Model):
    user= models.ForeignKey(User,on_delete=models.CASCADE)
    def __str__(self) -> str:
        data = f"{self.user}order"
        return data

class UserAddress(models.Model):
    user= models.ForeignKey(User,on_delete=models.CASCADE)
    address = models.TextField(max_length=200)
    pincode = models.CharField(max_length=10)
    UserOder = models.ForeignKey(UserOder,on_delete=models.CASCADE,null=True)

    def __str__(self) -> str:
        return self.pincode
    

class UserCartItem(models.Model):
    cart= models.ForeignKey(UserOder,on_delete=models.CASCADE)
    product = models.ForeignKey(Product,on_delete=models.CASCADE)
    qnty = models.IntegerField(default=1)
    total_price = models.IntegerField(default=99)
    date = models.DateTimeField(auto_now_add=True)
    product_status = models.CharField(choices=STATUS_CHOICES,default="no_buy",max_length=20)
    status = models.BooleanField(default=False)
    address = models.ForeignKey(UserAddress,null=True,blank=True,on_delete=models.CASCADE)



    def __str__(self) -> str:
        data = f"{self.cart}_cartitem_{self.product}"
        return data
    

    
class SaveLikes(models.Model):
    user= models.ForeignKey(User,on_delete=models.CASCADE)
    product= models.ForeignKey(Product,on_delete=models.CASCADE)
    likes = models.IntegerField(default=0)

    def __str__(self) -> str:
        data = f"{self.product}_like_{self.likes}"
        return data