from django.urls import path
from . import views

urlpatterns = [
    path('', views.HomePageClass.as_view(), name='HomePage'),
    path('ProductView/<int:id>/', views.ProductViewClass.as_view(), name='ProductView'),
    path('AddtoCart/', views.AddToCartClass.as_view(), name='AddtoCart'),
    path('CartPage/', views.CartPageClass.as_view(), name='CartPage'),
    path('Update_Cart_Item/', views.CartPageUpdateCartClass.as_view(), name='UpdateCartItem'),
    path('Cart_Item_Delete/<int:id>/', views.CartPageDeleteCartClass.as_view(), name='CartPageDeleteCartClass'),
    path('PaymentClass/<str:payment>/', views.PaymentClass.as_view(), name='PaymentClass'),
    path('CheckOut', views.CheckOutClass.as_view(), name='CheckOut'),



    path('SaveLikes/<str:id>/', views.SaveLikesfunction, name='SaveLikes'),
    path('address_add/', views.address_add, name='address_add'),
    path('address_delete/<str:id>/', views.address_delete, name='address_delete'),
]