from django.urls import path
from . import views

urlpatterns = [
    path('', views.HomePage, name='HomePage'),
    path('ProductView/<int:id>/', views.ProductView, name='ProductView'),
    path('CartPage/', views.CartPage, name='CartPage'),
    path('AddtoCart/', views.AddtoCart, name='AddtoCart'),
    path('qnt_inc_dic/', views.qnt_inc_dic, name='qnt_inc_dic'),
    path('Discount/', views.Discount, name='Discount'),
    path('DeleteCart/<str:id>/', views.DeleteCart, name='DeleteCart'),
    path('Checkout/', views.Checkout, name='Checkout'),
    path('SaveLikes/<str:id>/', views.SaveLikesfunction, name='SaveLikes'),
    path('address_add/', views.address_add, name='address_add'),
    path('address_delete/<str:id>/', views.address_delete, name='address_delete'),
]