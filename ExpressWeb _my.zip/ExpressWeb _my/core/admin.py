from django.contrib import admin

from .models import Product ,Category,UserOder,UserCartItem,UserAddress,SaveLikes

class ProductAdmin(admin.ModelAdmin):
  list_display =['title','user','price','category']


class UserCartItemAdmin(admin.ModelAdmin):
  list_display =['cart','status','product_status','product','address']

class SaveLikesAdmin(admin.ModelAdmin):
  list_display =['product','likes']

admin.site.register(Product,ProductAdmin)
admin.site.register(Category)

admin.site.register(UserOder)
admin.site.register(UserCartItem,UserCartItemAdmin)
admin.site.register(UserAddress)
admin.site.register(SaveLikes,SaveLikesAdmin)