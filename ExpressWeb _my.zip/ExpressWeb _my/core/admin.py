from django.contrib import admin

from .models import Product ,Category,Cart,CartItem,UserAddress,SaveLikes

class ProductAdmin(admin.ModelAdmin):
  list_display =['id','title','price','category']


class UserCartItemAdmin(admin.ModelAdmin):
  list_display =['id','user','product','qnty','status']

class SaveLikesAdmin(admin.ModelAdmin):
  list_display =['product','likes']


class CartAdmin(admin.ModelAdmin):
  list_display =['id','order_id','payment','product_status','status','address']


admin.site.register(Product,ProductAdmin)
admin.site.register(Category)

admin.site.register(Cart,CartAdmin)
admin.site.register(CartItem,UserCartItemAdmin)
admin.site.register(UserAddress)
admin.site.register(SaveLikes,SaveLikesAdmin)