from django.shortcuts import render,HttpResponse,redirect

from .models import Product,Category,UserOder,UserCartItem,SaveLikes,UserAddress
from django.db.models import Q
import random
import datetime
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.contrib.auth.decorators import login_required
import pdb
from django.db.models import Count

def HomePage(request):
    # products = Product.objects.annotate(like_count=Count('productlike'))
    # savelikeProduct = SaveLikes.objects.all()
    category_id = request.GET.get('category')
    price_search  = request.GET.get('valuedata')

    if category_id == None and price_search == None :
        products = Product.objects.annotate(like_count=Count('savelikes'))
        # products=Product.objects.all()
    elif category_id != None and price_search == None :
        products = Product.objects.filter(category_id=category_id)
    elif category_id == None and price_search != None :
        products = Product.objects.filter(price__lt=price_search)
    else:
        products = Product.objects.filter(Q(price__lt=price_search) |  Q(category_id=category_id))
    
    if request.method=="POST":
        search = request.POST.get("search")
        if len(search)>=3:
            products = Product.objects.filter(Q(title__icontains=search) | Q(description__icontains=search) )
        else:
            messages.success(request,"Add More Word in Search...")
            products=Product.objects.all()


    categories = Category.objects.all()
    context ={'products':products,'categories':categories}
    return render (request,'Pages/home.html',context)


def ProductView(request,id):
    product_details = Product.objects.get(id=id)
    dis = product_details.discount
    price = product_details.price
    if product_details.sale:
        discount_amount = (dis+10 / 100) * price

    discount_amount = (dis / 100) * price
    final_price = price - discount_amount

    context = {"details":product_details ,"filal_price":final_price}

    return render (request,'Pages/ProductsView.html',context)


@login_required(login_url='Login')
def AddtoCart(request):
    if request.method== "POST":
        quantity = request.POST.get("quantity")
        product=Product.objects.get(id = request.POST.get("product_id"))
        user = request.user
        my_order,_ = UserOder.objects.get_or_create(user = user)
        User_cart = UserCartItem.objects.filter(cart=my_order,product=product).first()
        if User_cart:
            print("Alredy Exisist")
            total_price = int(User_cart.qnty+int(quantity))*int(product.price)
            UserCartItem.objects.update(qnty=User_cart.qnty+int(quantity),total_price = total_price)
        else:
            total_price = int(quantity)*int(product.price)
            address= UserAddress.objects.filter(user=request.user).first()
            my_cart = UserCartItem.objects.create(cart=my_order,product=product,qnty=quantity,total_price=total_price,address=address)
        messages.success(request,f"Add {product.title} In Cart ")

        return redirect(f"/ProductView/{request.POST.get('product_id')}/")

    return redirect ("HomePage")
@login_required(login_url='Login')
def CartPage(request):
    Auth_order = UserOder.objects.get(user=request.user)
    # delivered_confirm
    # Q(cart=Auth_order,product_status="no_buy") | Q(cart=Auth_order,product_status="delivered_confirm")
    my_order = UserCartItem.objects.filter(Q(cart=Auth_order,product_status="no_buy") | Q(cart=Auth_order,product_status="delivered_confirm"))
    tota_items =len([ i for i in my_order ])
    tota_price = sum([i.total_price for i in my_order])

    address=UserAddress.objects.filter(user = request.user)
    if request.method=="POST":
        drone = request.POST.get("drone") 
        address_cur=UserAddress.objects.get(id=drone)
        address_cur.UserOder = Auth_order
        address_cur.save()

        for i in my_order:
            i.address = address_cur
            i.save()

        print(drone,"_______________________skil ")
    context ={
        "my_order" :my_order,
        "tota_items":tota_items,
        "tota_price":tota_price,
        "address":address
    }
    return render (request,'Pages/CartPage.html',context)


def qnt_inc_dic(request):
    my_order,_ = UserOder.objects.get_or_create(user = request.user)
    if request.method=="POST":
        qnt = request.POST.get('quantity')
        p_id = request.POST.get('p_id')
        print("Product ID ",p_id)
        product = Product.objects.get(id=p_id)
        User_cart = UserCartItem.objects.get(cart=my_order,product=product)
        print("--------cartqnt----------",User_cart.qnty)
        print("----------db price--------",product.price)
        print("-----qnt my-------------",qnt)
        total_price = int(qnt)*(int(product.price))
        print(total_price)
        User_cart.qnty = qnt
        User_cart.total_price=total_price
        User_cart.save()
        return redirect("CartPage")
    return "Some This Wrong Go Slow "


def Discount(request):
    Codes = ["JAYPATEL","SALE"]
    if request.method=="POST":
        promo = request.POST.get('code')
        if promo in Codes:
            my_order = UserOder.objects.get(user = request.user)
            User_cart = UserCartItem.objects.filter(cart=my_order)
            for i in User_cart:
                if i.product.sale == True:
                    # discount_amount = (dis+10 / 100) * price
                    print("Discoutn-------------------",i.product.discount)
                    print("Price-------------------",i.product.price)
                    discount_amount = ((i.product.discount+10) / 100) * (i.product.price)
                    print("dISCOUNT AMOUTNT -------------------",discount_amount)

                    i.total_price = discount_amount
                    i.save()
                else:
                    messages.success(request,"This Product Not On Sale :< ")
        else:
            messages.success(request,"PROMO CODE Not Valid !!")

    return redirect("CartPage")
@login_required(login_url='Login')
def DeleteCart(request,id):
    delete_product = UserCartItem.objects.get(id=id)
    delete_product.delete()
    return redirect("CartPage")

@login_required
def Checkout(request):
    Auth_order = UserOder.objects.get(user=request.user )
    my_order = UserCartItem.objects.filter(cart=Auth_order,product_status="no_buy")
    for i in my_order:
        i.product_status="pending"
        i.save()
        if i.address == None:
            return redirect ("CartPage")
        
    if request.method=="POST":
        p_id = request.POST.get('p_id')
        print("ID :",p_id)
        ObjectData = UserCartItem.objects.get(id=p_id)
        ObjectData.delete()
        messages.success(request,"Product Delivery Done :< ")
    if request.POST.get(""):
        pass
    my_order = UserCartItem.objects.filter(cart=Auth_order)
    address=UserAddress.objects.filter(user = request.user)
    context ={
        "my_order" :my_order,
        "address":address
    }

    return render (request,'Pages/CheckoutPage.html',context)


@login_required(login_url='Login')
def SaveLikesfunction(request,id):
    product = Product.objects.get(id=id)
    likedata = SaveLikes.objects.filter(user =request.user,product =product)
    if likedata:
        likedata.delete()
    else:
        savelikeProduct= SaveLikes.objects.create(user =request.user,product =product,likes=1)
        savelikeProduct.save()


    return redirect("HomePage")


def address_add(request):
    if request.method == "POST":
        add = request.POST.get('address')
        pin = request.POST.get('pin')
        Useradd = UserAddress.objects.create(address =add ,pincode=pin,user=request.user)
        Useradd.save()
        return redirect ('UserProfile')
    return render (request,'Pages/Add_Address.html')


def address_delete(request,id):
    Userdelete= UserAddress.objects.get(id=id)
    Userdelete.delete()
    return redirect ('UserProfile')
