from typing import Any, Dict
from django.shortcuts import render,HttpResponse,redirect

from .models import Product,Category,Cart,CartItem,SaveLikes,UserAddress
from django.db.models import Q
import random
import datetime
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
import pdb
from django.db.models import Count


# Class Base View 
from django.views.generic import ListView,DetailView
from django.views.generic.edit  import CreateView
from django.views import View
from django.core.paginator import Paginator



# Ads
from collections import Counter
import re
class HomePageClass(ListView):
    model=Category
    template_name = 'Pages/home.html'
    context_object_name = 'categories'
    def get_context_data(self, **kwargs: Any) -> Dict[str, Any]:
        context = super().get_context_data(**kwargs)
        category_id = self.request.GET.get('category')
        search_q = self.request.GET.get('search')
        if category_id:
            products = Product.objects.filter(category_id=category_id)
        elif search_q:
            products = Product.objects.filter(Q(title__icontains=search_q) | Q(description__icontains=search_q) )
        else:
            products=Product.objects.all()

        products_final = products.annotate(likes = Count('savelikes'))
        # Pagination
        page_number = self.request.GET.get('page', 1)
        items_per_page = 3
        paginator = Paginator(products_final, items_per_page)
        page = paginator.get_page(page_number)
        context['products'] = page

        #  My Ads 
        if self.request.user.is_authenticated:
            from collections import Counter
            User_save_products = SaveLikes.objects.filter(user=self.request.user)
            # category
            User_intrest_cat = [i.product.category.id for i in User_save_products]
            number_counts = Counter(User_intrest_cat)
            ads_data = list(number_counts.keys())
            Banner = Product.objects.filter(category__in=ads_data).order_by('price')[:5]
        else:
            Banner= None

        # price

        context['ads_product'] = Banner
        return context

    
    
class ProductViewClass(DetailView):
    model=Product
    template_name = 'Pages/ProductsView.html'
    context_object_name = 'details'
    pk_url_kwarg = 'id'


class AddToCartClass(LoginRequiredMixin,View):
    login_url = 'Login'
    def post(self,request):
        quantity = request.POST.get("quantity")
        product=Product.objects.get(id = request.POST.get("product_id"))
        user = request.user
        User_cart = CartItem.objects.filter(user=user,product=product,status = False)
        if User_cart:
            User_cart = CartItem.objects.get(user=user,product=product,status = False)
            print("Alredy Exisist")
            newqnty = User_cart.qnty +int(quantity)
            User_cart.qnty = newqnty
            User_cart.save()
        else:
            my_cart = CartItem.objects.create(user=user,product=product,qnty=quantity,status = False)

        return redirect(f"/ProductView/{request.POST.get('product_id')}/")
    
import random

class CartPageClass(LoginRequiredMixin,View):
    login_url = 'Login'
    def get(self,request):
        my_order = CartItem.objects.filter(user = request.user,status = False)
        my_address = UserAddress.objects.filter(user = request.user)
        total_price = CartItem.total_price(my_order)
        context = {'my_order':my_order,'my_address':my_address ,'total':total_price}
        return render (request,'Pages/CartPage.html',context)
    
    def post(self,request):
        address_id = request.POST.get('drone')
        if not address_id:
            messages.success(request,"Select Address ")
            return redirect ('CartPage')
        user = request.user
        order_id =f"{user}_order{random.randint(1000,9999)}"
        product_list = CartItem.objects.filter(user=user,status =False)
        total_price  =CartItem.total_price(product_list)
        product = None
        status = False
        address  = UserAddress.objects.get(id=address_id)
        My_order,_ = Cart.objects.get_or_create(user=user,address=address,status = status)
        My_order.order_id = order_id
        My_order.total_price = total_price
        product_add = set()
        for i in product_list:
            my_pro = CartItem.objects.get(id=i.pk)
            My_order.product.add(my_pro)
        My_order.save()

    
        return render (request,'Pages/Payment.html')
    
class CartPageUpdateCartClass(LoginRequiredMixin,View):
    login_url = 'Login'
    def post(self,request):
        qnt = request.POST.get('quantity')
        p_id = request.POST.get('p_id')
        CartObject = CartItem.objects.get(product__id=p_id,status=False)
        CartObject.qnty = qnt
        CartObject.save()
        return redirect ('CartPage')
    

class CartPageDeleteCartClass(LoginRequiredMixin,View):    
    login_url = 'Login'
    def get(self,request,id):
        CartObject = CartItem.objects.get(id=id)
        CartObject.delete()
        return redirect ('CartPage')


class PaymentClass(LoginRequiredMixin,View):
    login_url = 'Login'
    def get(self,request,payment):
        if payment == "Paytm":
            return HttpResponse("Sorry This Payment Method Under Cunstruction")
        elif payment == "Cash":
            My_Order = Cart.objects.get(user=request.user,status =False)
            print("CASH")
            My_Order.payment ='cash'
            My_Order.status = True
            My_Order.save()

            My_Cart = CartItem.objects.filter(user=request.user,status =False).first()
            My_Cart.status = True
            My_Cart.save()
            return redirect ('CheckOut')
        else:
            return HttpResponse("Some thing Wrong ...")

    

class CheckOutClass(LoginRequiredMixin,View):
    login_url = 'Login'
    def get(self,request):
        My_order = Cart.objects.filter(user=request.user,product_status__in = ['pending','on_the_way','delivered']).order_by('-date')
        My_hist = Cart.objects.filter(user=request.user,product_status = 'delivered_confirm').order_by('-date')
        print(My_order)
        context ={"My_order":My_order, "My_hist":My_hist}
        return render (request,'Pages/CheckoutPage.html',context)
    
    def post(self,request):
        p_id = request.POST.get('p_id')
        My_order= Cart.objects.get(id=p_id)
        My_order.status = True
        My_order.product_status = 'delivered_confirm'
        My_order.save()
        return redirect('CheckOut')



@login_required(login_url='Login')
def SaveLikesfunction(request,id):
    product = Product.objects.get(id=id)
    likedata = SaveLikes.objects.filter(user =request.user,product =product)
    if likedata:
        likedata.delete()
    else:
        savelikeProduct= SaveLikes.objects.create(user =request.user,product =product,likes=1)
        savelikeProduct.save()


    return redirect("HomePage")

@login_required(login_url='Login')
def address_add(request):
    if request.method == "POST":
        add = request.POST.get('address')
        pin = request.POST.get('pin')
        Useradd = UserAddress.objects.create(address =add ,pincode=pin,user=request.user)
        Useradd.save()
        return redirect ('UserProfile')
    return render (request,'Pages/Add_Address.html')

@login_required(login_url='Login')
def address_delete(request,id):
    Userdelete= UserAddress.objects.get(id=id)
    Userdelete.delete()
    return redirect ('UserProfile')
